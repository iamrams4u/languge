﻿using System;
using System.Collections.Generic;
using LocalizationSample.Resources;
using Xamarin.Forms;

namespace LocalizationSample
{
    public partial class HomePage : ContentPage
    {
        public HomePage()
        {
            InitializeComponent();
            PizzaLabel.Text= AppResources.LovePizza;
        }

       
    }
}
